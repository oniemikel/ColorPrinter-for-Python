from .main import ColorPrinter, print

__all__ = ['ColorPrinter', 'print']